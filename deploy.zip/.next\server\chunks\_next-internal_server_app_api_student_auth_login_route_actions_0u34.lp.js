module.exports=[62557,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_auth_login_route_actions_0u34.lp.js.map