module.exports=[11959,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_faculty_messages_page_actions_0u~9qoz.js.map