var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/auth/reset-password/route.js")
R.c("server/chunks/[root-of-the-server]__0m2f.i4._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/_next-internal_server_app_api_student_auth_reset-password_route_actions_0~j_ivm.js")
R.m(94390)
module.exports=R.m(94390).exports
