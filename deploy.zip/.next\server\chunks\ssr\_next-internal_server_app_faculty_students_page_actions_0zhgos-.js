module.exports=[63387,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_faculty_students_page_actions_0zhgos-.js.map