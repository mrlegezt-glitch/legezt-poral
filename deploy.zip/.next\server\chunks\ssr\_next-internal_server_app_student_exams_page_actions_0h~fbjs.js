module.exports=[9548,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_student_exams_page_actions_0h~fbjs.js.map