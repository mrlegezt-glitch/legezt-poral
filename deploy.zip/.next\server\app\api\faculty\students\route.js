var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/faculty/students/route.js")
R.c("server/chunks/[root-of-the-server]__0s82a3y._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/_next-internal_server_app_api_faculty_students_route_actions_0zsu1w0.js")
R.m(97169)
module.exports=R.m(97169).exports
