var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/exams/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0.yupgd._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/_next-internal_server_app_api_student_exams_[id]_route_actions_00_482l.js")
R.m(19424)
module.exports=R.m(19424).exports
