module.exports=[18314,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_faculty_public_route_actions_0dcl3-l.js.map