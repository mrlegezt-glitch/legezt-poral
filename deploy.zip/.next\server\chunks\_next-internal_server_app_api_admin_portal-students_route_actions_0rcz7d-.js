module.exports=[62642,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_portal-students_route_actions_0rcz7d-.js.map