module.exports=[56340,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_faculty_exams_create_route_actions_0ttu6~f.js.map