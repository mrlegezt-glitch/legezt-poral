module.exports=[58624,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_exams_results_route_actions_04gr32f.js.map