module.exports=[54559,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_faculty_exams_%5Bid%5D_publish_route_actions_0e1mioa.js.map