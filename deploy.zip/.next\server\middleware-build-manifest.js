globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/wKC4Jngbn2tOJ0unoTspo/_buildManifest.js",
    "static/wKC4Jngbn2tOJ0unoTspo/_ssgManifest.js",
    "static/wKC4Jngbn2tOJ0unoTspo/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/15pjn.n4_q6le.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/0c7h~x4_chf35.js",
    "static/chunks/turbopack-0kemc0e062jzz.js"
  ]
};
