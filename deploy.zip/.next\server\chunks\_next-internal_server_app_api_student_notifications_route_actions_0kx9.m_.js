module.exports=[4479,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_notifications_route_actions_0kx9.m_.js.map