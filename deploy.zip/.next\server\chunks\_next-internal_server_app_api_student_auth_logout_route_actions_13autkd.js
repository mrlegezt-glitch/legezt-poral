module.exports=[42284,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_auth_logout_route_actions_13autkd.js.map