module.exports=[10508,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_auth_forgot-password_route_actions_0i~c1mw.js.map