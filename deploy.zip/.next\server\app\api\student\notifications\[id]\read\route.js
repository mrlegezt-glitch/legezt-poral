var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/notifications/[id]/read/route.js")
R.c("server/chunks/[root-of-the-server]__0zrzod.._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/0zjb_server_app_api_student_notifications_[id]_read_route_actions_0nl1m.r.js")
R.m(26780)
module.exports=R.m(26780).exports
