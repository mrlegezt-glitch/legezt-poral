module.exports=[19558,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_faculty_login_page_actions_0uo1jz_.js.map