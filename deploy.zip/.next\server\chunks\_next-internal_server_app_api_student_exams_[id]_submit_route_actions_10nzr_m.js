module.exports=[25105,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_exams_%5Bid%5D_submit_route_actions_10nzr_m.js.map