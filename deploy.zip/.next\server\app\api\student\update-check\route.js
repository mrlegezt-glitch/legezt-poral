var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/update-check/route.js")
R.c("server/chunks/[root-of-the-server]__0st2apv._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/_next-internal_server_app_api_student_update-check_route_actions_0xo17pc.js")
R.m(99764)
module.exports=R.m(99764).exports
