var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/auth/forgot-password/route.js")
R.c("server/chunks/[root-of-the-server]__0z8cpzw._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__0c4b905._.js")
R.c("server/chunks/_next-internal_server_app_api_student_auth_forgot-password_route_actions_0i~c1mw.js")
R.m(51001)
module.exports=R.m(51001).exports
