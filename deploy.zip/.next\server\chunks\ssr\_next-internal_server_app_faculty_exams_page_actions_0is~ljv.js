module.exports=[59142,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_faculty_exams_page_actions_0is~ljv.js.map