var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/faculty/auth/register/route.js")
R.c("server/chunks/[root-of-the-server]__0~t_p5t._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_131y~ke.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/_next-internal_server_app_api_faculty_auth_register_route_actions_07-j62y.js")
R.m(15070)
module.exports=R.m(15070).exports
