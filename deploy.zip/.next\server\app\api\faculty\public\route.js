var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/faculty/public/route.js")
R.c("server/chunks/[root-of-the-server]__0vo-7fk._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/_next-internal_server_app_api_faculty_public_route_actions_0dcl3-l.js")
R.m(91800)
module.exports=R.m(91800).exports
