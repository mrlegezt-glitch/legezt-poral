var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/csv-export/route.js")
R.c("server/chunks/[root-of-the-server]__0k0yc2n._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_csv-export_route_actions_0nqrirs.js")
R.m(55918)
module.exports=R.m(55918).exports
