module.exports=[3821,e=>{"use strict";var t=e.i(15270);async function s(e){try{let s=await t.default.examSubmission.findUnique({where:{id:e},include:{student:!0,exam:{include:{questions:!0,faculty:!0}},anomaliesLog:!0}});if(!s)return void console.error(`[Post-Exam Pipeline] Submission not found: ${e}`);let{student:i,exam:o}=s,{questions:r,faculty:n}=o;console.log(`[Post-Exam Pipeline] Initializing for Student: ${i.fullName}, Exam: ${o.title}`);let l=r.length-s.score/(r[0]?.marks||1),c=process.env.GEMINI_API_KEY,m="Ensure you review the syllabus sections on your recent surprise exam.";if(c)try{let e=`Act as an expert computer science professor. A student named ${i.fullName} has completed a surprise examination titled "${o.title}" with a score of ${s.score}/${r.length*(r[0]?.marks||1)}. Status: ${s.status}. Number of incorrect answers: ${l}. Anomalies recorded: ${s.anomaliesLog.length}. Provide a detailed, professional, encouraging academic review outlining typical mistakes they might have made in these exam concepts and provide clear rationales. Return strictly the plain text markdown. Do not use emojis.`,t=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${c}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:e}]}]})});if(t.ok){let e=await t.json(),s=e.candidates?.[0]?.content?.parts?.[0]?.text;s&&(m=s)}}catch(e){console.error("[Post-Exam Pipeline] Gemini API mistake brief fetch error:",e)}console.log(`
=========================================
[SMTP OUTGOING] TO: ${i.email}
[SUBJECT] Academic Performance Report: ${o.title}
-----------------------------------------
Dear ${i.fullName},

Your secure surprise examination sheet has been graded.
Status: ${s.status.toUpperCase()}
Score: ${s.score} Marks

CONCEPT RATIONALE & FEEDBACK:
${m}

Best regards,
Lords Academic Network Node
=========================================
    `),await a(o.id,n.workEmail,n.fullName)}catch(e){console.error("[Post-Exam Pipeline] Runtime error:",e)}}async function a(e,s,a){try{let i=await t.default.exam.findUnique({where:{id:e},include:{submissions:{include:{student:!0}}}});if(!i)return;let o=i.submissions.length;if(0===o)return;let r=i.submissions.map(e=>e.score),n=(r.reduce((e,t)=>e+t,0)/o).toFixed(1),l=Math.max(...r),c=i.submissions.filter(e=>"terminated"===e.status).length,m=process.env.GEMINI_API_KEY,d="Review class materials periodically to raise score distribution profiles.";if(m)try{let e=`Act as a senior educational psychologist and academic auditor. You are analyzing surprise exam results for the class. Exam Title: "${i.title}". Total students taken: ${o}. Average Score: ${n}. Highest Score: ${l}. Forcibly Terminated due to proctoring breaches: ${c}. Provide 3 critical, actionable teaching insights and security recommendations based on these class stats. Return strictly a professional plain text markdown layout. Do not use emojis.`,t=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${m}`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{parts:[{text:e}]}]})});if(t.ok){let e=await t.json(),s=e.candidates?.[0]?.content?.parts?.[0]?.text;s&&(d=s)}}catch(e){console.error("[Post-Exam Pipeline] Gemini API faculty insights fetch error:",e)}console.log(`
=========================================
[SMTP OUTGOING] TO: ${s}
[SUBJECT] Consolidated Performance PDF Report: ${i.title}
[ATTACHMENT] Consolidated_Summary_Report_${e}.pdf
-----------------------------------------
Dear Prof. ${a},

Enclosed is the Consolidated Performance Summary PDF Report for your recent surprise exam.

EXAM METRICS BOARD:
- Total Submissions: ${o}
- Class Average Score: ${n} Marks
- Peak Score: ${l} Marks
- Security Terminations: ${c}

AI-GENERATED PERFORMANCE EVALUATION & AUDIT INSIGHTS:
${d}

Best regards,
SCSES Automated Audit Pipeline
=========================================
    `)}catch(e){console.error("[Post-Exam Pipeline] Failed compiling faculty report:",e)}}e.s(["processPostExamPipeline",0,s])}];

//# sourceMappingURL=lib_exams_ts_03_ztj_._.js.map