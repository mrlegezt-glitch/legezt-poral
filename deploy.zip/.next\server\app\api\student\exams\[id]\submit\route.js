var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/exams/[id]/submit/route.js")
R.c("server/chunks/[root-of-the-server]__0j7_php._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/_next-internal_server_app_api_student_exams_[id]_submit_route_actions_10nzr_m.js")
R.m(57084)
module.exports=R.m(57084).exports
