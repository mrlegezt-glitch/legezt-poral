module.exports=[79597,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_student_documents_page_actions_0tij32i.js.map