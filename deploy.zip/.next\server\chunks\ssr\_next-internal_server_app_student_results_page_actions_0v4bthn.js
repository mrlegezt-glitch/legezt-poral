module.exports=[7054,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_student_results_page_actions_0v4bthn.js.map