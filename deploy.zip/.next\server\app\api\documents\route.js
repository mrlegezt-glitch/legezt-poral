var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/documents/route.js")
R.c("server/chunks/[root-of-the-server]__0wqex32._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/[root-of-the-server]__0_qwb3t._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/_next-internal_server_app_api_documents_route_actions_0ykfuvn.js")
R.m(18069)
module.exports=R.m(18069).exports
