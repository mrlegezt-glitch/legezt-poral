module.exports=[40786,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_friends_route_actions_0xskmdu.js.map