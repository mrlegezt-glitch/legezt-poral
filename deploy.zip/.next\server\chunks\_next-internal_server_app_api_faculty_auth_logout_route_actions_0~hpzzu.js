module.exports=[18627,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_faculty_auth_logout_route_actions_0~hpzzu.js.map