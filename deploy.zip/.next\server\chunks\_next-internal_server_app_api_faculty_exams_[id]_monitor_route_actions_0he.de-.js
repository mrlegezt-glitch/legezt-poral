module.exports=[39264,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_faculty_exams_%5Bid%5D_monitor_route_actions_0he.de-.js.map