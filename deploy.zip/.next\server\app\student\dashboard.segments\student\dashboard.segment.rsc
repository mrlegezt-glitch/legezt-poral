1:"$Sreact.fragment"
2:I[46582,["/_next/static/chunks/04lr7976r~ws6.js","/_next/static/chunks/0d3shmwh5_nmn.js","/_next/static/chunks/0cnzzh.rtggte.js"],"default"]
3:I[39756,["/_next/static/chunks/04lr7976r~ws6.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
4:I[37457,["/_next/static/chunks/04lr7976r~ws6.js","/_next/static/chunks/0d3shmwh5_nmn.js"],"default"]
0:{"rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/0cnzzh.rtggte.js","async":true}]],["$","$L2",null,{"children":["$","$L3",null,{"parallelRouterKey":"children","template":["$","$L4",null,{}]}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"wKC4Jngbn2tOJ0unoTspo"}
