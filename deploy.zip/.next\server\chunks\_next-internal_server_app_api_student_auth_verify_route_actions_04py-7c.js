module.exports=[81143,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_auth_verify_route_actions_04py-7c.js.map