module.exports=[30086,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_student_register_page_actions_0l6ia-5.js.map