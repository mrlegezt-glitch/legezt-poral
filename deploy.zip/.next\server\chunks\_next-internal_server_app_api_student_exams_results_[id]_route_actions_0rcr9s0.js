module.exports=[47631,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_exams_results_%5Bid%5D_route_actions_0rcr9s0.js.map