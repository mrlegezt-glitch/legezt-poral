var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/faculty/exams/[id]/monitor/route.js")
R.c("server/chunks/[root-of-the-server]__053ixvi._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/_next-internal_server_app_api_faculty_exams_[id]_monitor_route_actions_0he.de-.js")
R.m(48909)
module.exports=R.m(48909).exports
