module.exports=[88557,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_student_profile_page_actions_08o9s-5.js.map