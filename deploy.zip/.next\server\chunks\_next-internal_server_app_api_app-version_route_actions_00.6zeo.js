module.exports=[16741,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_app-version_route_actions_00.6zeo.js.map