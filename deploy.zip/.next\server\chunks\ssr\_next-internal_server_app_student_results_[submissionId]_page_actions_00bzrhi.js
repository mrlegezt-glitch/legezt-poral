module.exports=[49054,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_student_results_%5BsubmissionId%5D_page_actions_00bzrhi.js.map