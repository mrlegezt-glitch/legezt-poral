module.exports=[56214,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_auth_register_route_actions_0q7z~69.js.map