module.exports=[67587,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_faculty_dashboard_page_actions_0s4uhle.js.map