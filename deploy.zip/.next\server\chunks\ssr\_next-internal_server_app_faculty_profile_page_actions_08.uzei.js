module.exports=[91830,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_faculty_profile_page_actions_08.uzei.js.map