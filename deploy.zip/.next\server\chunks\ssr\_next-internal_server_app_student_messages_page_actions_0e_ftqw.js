module.exports=[20769,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_student_messages_page_actions_0e_ftqw.js.map