var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__07-dpxn._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_131y~ke.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/_next-internal_server_app_api_student_auth_login_route_actions_0u34.lp.js")
R.m(98410)
module.exports=R.m(98410).exports
