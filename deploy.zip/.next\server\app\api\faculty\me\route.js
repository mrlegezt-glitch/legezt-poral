var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/faculty/me/route.js")
R.c("server/chunks/[root-of-the-server]__0mopomw._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/_next-internal_server_app_api_faculty_me_route_actions_1050-56.js")
R.m(90843)
module.exports=R.m(90843).exports
