module.exports=[11496,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_exams_%5Bid%5D_anomaly_route_actions_10q9s.v.js.map