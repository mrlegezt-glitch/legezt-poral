var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/faculty/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0h-g9r4._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/_next-internal_server_app_api_faculty_auth_logout_route_actions_0~hpzzu.js")
R.m(82379)
module.exports=R.m(82379).exports
