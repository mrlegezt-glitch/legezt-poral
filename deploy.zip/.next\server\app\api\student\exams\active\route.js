var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/exams/active/route.js")
R.c("server/chunks/[root-of-the-server]__0_f~nn5._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/_next-internal_server_app_api_student_exams_active_route_actions_05de17r.js")
R.m(98996)
module.exports=R.m(98996).exports
