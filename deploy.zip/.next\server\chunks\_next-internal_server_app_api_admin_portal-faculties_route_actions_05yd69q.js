module.exports=[19998,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_portal-faculties_route_actions_05yd69q.js.map