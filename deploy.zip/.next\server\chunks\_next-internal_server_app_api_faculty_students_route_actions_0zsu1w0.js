module.exports=[62253,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_faculty_students_route_actions_0zsu1w0.js.map