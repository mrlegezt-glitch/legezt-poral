module.exports=[94921,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_me_route_actions_0fzh148.js.map