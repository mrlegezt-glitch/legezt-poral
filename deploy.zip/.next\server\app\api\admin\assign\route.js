var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/assign/route.js")
R.c("server/chunks/[root-of-the-server]__0f0.9tr._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_assign_route_actions_02yrla_.js")
R.m(9450)
module.exports=R.m(9450).exports
