var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/friends/route.js")
R.c("server/chunks/[root-of-the-server]__0pl3m25._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/_next-internal_server_app_api_student_friends_route_actions_0xskmdu.js")
R.m(79468)
module.exports=R.m(79468).exports
