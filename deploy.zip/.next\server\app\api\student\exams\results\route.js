var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/exams/results/route.js")
R.c("server/chunks/[root-of-the-server]__12.md5n._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/_next-internal_server_app_api_student_exams_results_route_actions_04gr32f.js")
R.m(81411)
module.exports=R.m(81411).exports
