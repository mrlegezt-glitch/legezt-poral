var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/auth/verify/route.js")
R.c("server/chunks/[root-of-the-server]__0c_cnqy._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/_next-internal_server_app_api_student_auth_verify_route_actions_04py-7c.js")
R.m(56290)
module.exports=R.m(56290).exports
