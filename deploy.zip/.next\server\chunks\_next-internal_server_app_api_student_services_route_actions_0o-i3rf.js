module.exports=[70809,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_services_route_actions_0o-i3rf.js.map