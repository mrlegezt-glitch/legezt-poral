var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/faculty/exams/questions/import/route.js")
R.c("server/chunks/[root-of-the-server]__0fdv8qd._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/0zjb_server_app_api_faculty_exams_questions_import_route_actions_0bp1q5c.js")
R.m(95002)
module.exports=R.m(95002).exports
