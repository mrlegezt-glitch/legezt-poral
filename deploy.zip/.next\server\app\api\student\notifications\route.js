var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/notifications/route.js")
R.c("server/chunks/[root-of-the-server]__0lok04a._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/_next-internal_server_app_api_student_notifications_route_actions_0kx9.m_.js")
R.m(39670)
module.exports=R.m(39670).exports
