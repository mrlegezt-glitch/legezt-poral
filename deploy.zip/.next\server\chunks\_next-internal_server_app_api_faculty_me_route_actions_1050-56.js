module.exports=[19953,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_faculty_me_route_actions_1050-56.js.map