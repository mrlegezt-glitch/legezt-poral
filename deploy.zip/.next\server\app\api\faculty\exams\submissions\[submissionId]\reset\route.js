var R=require("../../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/faculty/exams/submissions/[submissionId]/reset/route.js")
R.c("server/chunks/[root-of-the-server]__10~n9bt._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/0wuz_app_api_faculty_exams_submissions_[submissionId]_reset_route_actions_0pus~f1.js")
R.m(13026)
module.exports=R.m(13026).exports
