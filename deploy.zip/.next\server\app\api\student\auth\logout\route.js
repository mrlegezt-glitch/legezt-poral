var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__0.j6dib._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/_next-internal_server_app_api_student_auth_logout_route_actions_13autkd.js")
R.m(18044)
module.exports=R.m(18044).exports
