var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/faculty/exams/[id]/publish/route.js")
R.c("server/chunks/[root-of-the-server]__0kt~0be._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/_next-internal_server_app_api_faculty_exams_[id]_publish_route_actions_0e1mioa.js")
R.m(31343)
module.exports=R.m(31343).exports
