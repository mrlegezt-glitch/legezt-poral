module.exports=[58034,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_exams_%5Bid%5D_route_actions_00_482l.js.map