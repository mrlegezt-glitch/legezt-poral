var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/me/route.js")
R.c("server/chunks/[root-of-the-server]__0djm-f6._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/_next-internal_server_app_api_student_me_route_actions_0fzh148.js")
R.m(10070)
module.exports=R.m(10070).exports
