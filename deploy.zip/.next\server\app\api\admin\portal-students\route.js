var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/portal-students/route.js")
R.c("server/chunks/[root-of-the-server]__0x4.4pp._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_portal-students_route_actions_0rcz7d-.js")
R.m(38173)
module.exports=R.m(38173).exports
