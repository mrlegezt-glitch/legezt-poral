module.exports=[45575,(e,o,d)=>{}];

//# sourceMappingURL=0wuz_app_api_faculty_exams_submissions_%5BsubmissionId%5D_reset_route_actions_0pus~f1.js.map