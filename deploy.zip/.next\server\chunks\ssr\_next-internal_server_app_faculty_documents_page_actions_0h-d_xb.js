module.exports=[47781,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_faculty_documents_page_actions_0h-d_xb.js.map