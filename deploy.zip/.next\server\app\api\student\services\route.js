var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/services/route.js")
R.c("server/chunks/[root-of-the-server]__0gya2j8._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/_next-internal_server_app_api_student_services_route_actions_0o-i3rf.js")
R.m(52527)
module.exports=R.m(52527).exports
