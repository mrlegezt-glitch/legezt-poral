var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/exams/results/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0y.-5z6._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/_next-internal_server_app_api_student_exams_results_[id]_route_actions_0rcr9s0.js")
R.m(5153)
module.exports=R.m(5153).exports
