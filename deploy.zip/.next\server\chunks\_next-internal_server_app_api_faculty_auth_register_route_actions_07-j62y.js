module.exports=[94729,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_faculty_auth_register_route_actions_07-j62y.js.map