var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/auth/register/route.js")
R.c("server/chunks/[root-of-the-server]__0~jyhm3._.js")
R.c("server/chunks/[root-of-the-server]__0c4b905._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_131y~ke.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/_next-internal_server_app_api_student_auth_register_route_actions_0q7z~69.js")
R.m(84990)
module.exports=R.m(84990).exports
