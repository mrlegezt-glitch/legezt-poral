module.exports=[90629,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_update-check_route_actions_0xo17pc.js.map