var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/portal-faculties/route.js")
R.c("server/chunks/[root-of-the-server]__0ud26u0._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_portal-faculties_route_actions_05yd69q.js")
R.m(33888)
module.exports=R.m(33888).exports
