var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/faculty/exams/create/route.js")
R.c("server/chunks/[root-of-the-server]__0rwrma5._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/_next-internal_server_app_api_faculty_exams_create_route_actions_0ttu6~f.js")
R.m(73064)
module.exports=R.m(73064).exports
