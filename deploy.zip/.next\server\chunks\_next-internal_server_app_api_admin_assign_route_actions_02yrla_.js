module.exports=[35277,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_assign_route_actions_02yrla_.js.map