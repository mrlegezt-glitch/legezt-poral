module.exports=[75244,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_auth_reset-password_route_actions_0~j_ivm.js.map