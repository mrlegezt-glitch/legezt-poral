module.exports=[71617,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_student_notifications_%5Bid%5D_read_route_actions_0nl1m.r.js.map