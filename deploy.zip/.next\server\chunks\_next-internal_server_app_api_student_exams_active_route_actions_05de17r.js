module.exports=[1072,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_exams_active_route_actions_05de17r.js.map