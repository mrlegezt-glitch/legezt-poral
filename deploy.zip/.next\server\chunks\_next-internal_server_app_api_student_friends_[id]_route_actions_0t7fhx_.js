module.exports=[65739,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_student_friends_%5Bid%5D_route_actions_0t7fhx_.js.map