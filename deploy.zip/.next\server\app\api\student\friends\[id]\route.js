var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/friends/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0fwjwhx._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/_next-internal_server_app_api_student_friends_[id]_route_actions_0t7fhx_.js")
R.m(6748)
module.exports=R.m(6748).exports
