module.exports=[12793,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_faculty_auth_login_route_actions_0cp.ye..js.map