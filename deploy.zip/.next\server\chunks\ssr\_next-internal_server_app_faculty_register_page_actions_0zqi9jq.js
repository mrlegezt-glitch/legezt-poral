module.exports=[58428,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_faculty_register_page_actions_0zqi9jq.js.map