module.exports=[18174,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_student_login_page_actions_03lc59p.js.map