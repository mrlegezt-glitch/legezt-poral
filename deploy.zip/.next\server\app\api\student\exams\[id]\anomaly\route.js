var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/student/exams/[id]/anomaly/route.js")
R.c("server/chunks/[root-of-the-server]__0z0bg02._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/_next-internal_server_app_api_student_exams_[id]_anomaly_route_actions_10q9s.v.js")
R.m(26754)
module.exports=R.m(26754).exports
