var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/messages/route.js")
R.c("server/chunks/[root-of-the-server]__0m-gpjb._.js")
R.c("server/chunks/[root-of-the-server]__10jcncu._.js")
R.c("server/chunks/node_modules_zod_v4_classic_external_131y~ke.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/_next-internal_server_app_api_messages_route_actions_050o996.js")
R.m(17391)
module.exports=R.m(17391).exports
